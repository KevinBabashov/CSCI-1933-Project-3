Group members’ names and x500s
Kevin Babashov babas007
Takuya Paipoovong paipo001

• Contributions of each partner (if working with a partner)

Contributions were broken up between arrayList and LinkedList with Kevin finishing the ArrayList and then helping Takuya with debugging and writing the rest of the LinkedList
• How to compile and run your program
• Any assumptions
Assumption is made for Array Copy is that it is somewhere between O(1) and O(n)  complexity and it is assumed in the runtime analysis is O(1)
• Additional features that you implemented (if applicable)
No additional features

• Any known bugs or defects in the program

• Any outside sources (aside from course resources) consulted for ideas used in the project, in
the format:
– idea1: GeekForGeek
– idea2: Stack Overflow
– idea3: Oracle

“I certify that the information contained in this README
file is complete and accurate. I have both read and adhered to the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Kevin Babashov
Takuya Paipoovong